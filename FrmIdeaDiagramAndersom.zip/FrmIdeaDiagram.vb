﻿Imports System.Windows.Forms
Imports System.Drawing

Public Class FrmIdeaDiagram
    Private _Repository As EA.Repository
    Protected objDS As DataSet


    Public Property Repository() As EA.Repository
        Get
            Return _Repository
        End Get
        Set(ByVal value As EA.Repository)
            _Repository = value
        End Set
    End Property

    Private _Diagram As EA.Diagram
    Public Property Diagram() As EA.Diagram
        Get
            Return _Diagram
        End Get
        Set(ByVal value As EA.Diagram)
            _Diagram = value
            Me.LabelDiagramName.Text = _Diagram.Name
            Me.LabelMappingDiagramName.Text = _Diagram.Name
        End Set
    End Property
    Public Sub LoadElements()
        Dim objDS As DataSet
        Dim strSql As String
        strSql = String.Format("Select t_object.Object_ID as id, t_object.name from t_object, t_diagramobjects where t_object.Object_ID = t_diagramobjects.Object_ID and t_diagramobjects.Diagram_ID = {0} Order by t_object.Name", Me.Diagram.DiagramID)
        objDS = DLA2EAHelper.SQL2DataSet(strSql, Me.Repository)

        Me.ListBoxElements.DataSource = objDS.Tables(1)
        Me.ListBoxElements.DisplayMember = "name"
        Me.ListBoxElements.ValueMember = "id"

        Me.ListBoxMappingElement.DataSource = objDS.Tables(1)
        Me.ListBoxMappingElement.DisplayMember = "name"
        Me.ListBoxMappingElement.ValueMember = "id"
        CreateMappingGrid()

    End Sub
    Private Sub SelectDeSelectMapping(state As Boolean)
        Dim i As Int16 = 0
        While i < ListBoxMappingElement.Items.Count
            ListBoxMappingElement.SetItemChecked(i, state)
            i += 1
        End While
    End Sub

    Private Sub SelectDeSelect(state As Boolean)
        Dim i As Int16 = 0
        While i < ListBoxElements.Items.Count
            ListBoxElements.SetItemChecked(i, state)
            i += 1
        End While
    End Sub

    Private Sub SelectToggle()
        Dim i As Int16 = 0
        While i < ListBoxElements.Items.Count
            ListBoxElements.SetItemChecked(i, (Not ListBoxElements.GetItemChecked(i)))
            i += 1
        End While
    End Sub

    Private Sub ButtonSelectAll_Click(sender As Object, e As EventArgs) Handles ButtonSelectAll.Click
        SelectDeSelect(True)
    End Sub
    Private Sub ButtonUnselectAll_Click(sender As Object, e As EventArgs) Handles ButtonUnselectAll.Click
        SelectDeSelect(False)
    End Sub

    Private Sub ButtonToggleAll_Click(sender As Object, e As EventArgs) Handles ButtonToggleAll.Click
        SelectToggle()
    End Sub

    Private Sub ButtonGenerate_Click(sender As Object, e As EventArgs) Handles ButtonGenerate.Click
        Dim item As DataRowView
        Dim objNew As EA.Element
        Dim objElement As EA.Element
        Dim objGenerator As New IDEAGenerator()
        objGenerator.Repository = Me.Repository
        For Each item In Me.ListBoxElements.CheckedItems
            objElement = Repository.GetElementByID(item("id"))
            objNew = objGenerator.CreateElement(Me.TextBoxPrefix.Text & objElement.Name, Me.ListBoxType.SelectedItem.ToString(), objElement.PackageID)
            Dim objDS As DataSet
            Dim strSql As String
            strSql = String.Format("SELECT id as attribute_id, name FROM t_attribute WHERE object_id = {0} ORDER BY name", objElement.ElementID)
            objDS = DLA2EAHelper.SQL2DataSet(strSql, Me.Repository)
            Dim objDR As DataRow
            For Each objDR In objDS.Tables(1).Rows
                objGenerator.CopyAttribute(objElement, objNew, Me.ListBoxType.SelectedItem.ToString().ToUpper(), objDR("attribute_id"), Me.CheckBoxAttributeAssociation.Checked)
                If Not Me.CheckBoxAttributeAssociation.Checked Then
                    objGenerator.CreateTraceAssociation(objElement, objNew)
                End If
            Next
        Next

        Me.Close()
    End Sub
    Private Sub CreateMappingGrid()
        Me.DataGridViewMapping.ColumnCount = 3
        Me.DataGridViewMapping.Columns(0).Name = "target_attribute_id"

        Me.DataGridViewMapping.Columns(1).Name = "Target_attribute"
        Me.DataGridViewMapping.Columns(2).Name = "Target_entity"
        Me.DataGridViewMapping.Columns(0).Visible = False

        With DataGridViewMapping.ColumnHeadersDefaultCellStyle
            .BackColor = Color.Navy
            .ForeColor = Color.White
            .Font = New Font(DataGridViewMapping.Font, FontStyle.Bold)
        End With
        Dim cmb As New DataGridViewComboBoxColumn()
        cmb.HeaderText = "Type"
        cmb.Name = "type"
        cmb.MaxDropDownItems = 2
        cmb.Items.Add("Mapper")
        cmb.Items.Add("Merger")
        Me.DataGridViewMapping.Columns.Insert(0, cmb)

        Me.CreateSourceCombo()
    End Sub
    Private Sub ButtonMappingSource_Click(sender As Object, e As EventArgs) Handles ButtonMappingSource.Click
        Dim item As DataRowView


        Dim strElements As String = "-999"
        For Each item In Me.ListBoxMappingElement.CheckedItems
            strElements += ", " + item("id")
        Next
        Dim strSql As String
        strSql = String.Format("SELECT t_attribute.id as attribute_id, t_attribute.name + ' (' + t_object.name + ')' as attrname FROM t_attribute, t_object WHERE t_attribute.object_id = t_object.object_id AND t_object.object_id IN( {0} ) ORDER BY 2", strElements)
        strSql = DLA2EAHelper.SQLForEAP(strSql, Me.Repository)
        objDS = DLA2EAHelper.SQL2DataSet(strSql, Me.Repository)
        Dim cmb As DataGridViewComboBoxColumn
        cmb = TryCast(DataGridViewMapping.Columns(0), DataGridViewComboBoxColumn)
        cmb.DataSource = objDS.Tables(1)
        cmb.DisplayMember = "attrname"
        cmb.ValueMember = "attribute_id"
        cmb.Width = 200

        SelectDeSelectMapping(False)
    End Sub
    Private Sub CreateSourceCombo()
        Dim cmb As New DataGridViewComboBoxColumn()

        If Me.DataGridViewMapping.ColumnCount = 5 Then
            Me.DataGridViewMapping.Columns.RemoveAt(0)
        End If
        cmb.HeaderText = "Source"
        cmb.Name = "source_attribute_id"
        cmb.MaxDropDownItems = 10
        cmb.DefaultCellStyle = DataGridViewMapping.Columns(0).DefaultCellStyle

        Me.DataGridViewMapping.Columns.Insert(0, cmb)
        DataGridViewMapping.AutoResizeColumn(0)
    End Sub


    Private Sub ButtonMappingTarget_Click(sender As Object, e As EventArgs) Handles ButtonMappingTarget.Click
        Dim item As DataRowView
        Dim objElement As EA.Element
        Me.DataGridViewMapping.Rows.Clear()
        For Each item In Me.ListBoxMappingElement.CheckedItems
            objElement = Repository.GetElementByID(item("id"))
            Dim objDS As DataSet
            Dim strSql As String
            strSql = String.Format("SELECT id as attribute_id, name FROM t_attribute WHERE object_id = {0} ORDER BY name", objElement.ElementID)

            objDS = DLA2EAHelper.SQL2DataSet(strSql, Me.Repository)
            Dim objDR As DataRow
            For Each objDR In objDS.Tables(1).Rows
                Dim row As String()
                row = {"", "Mapper", objDR.Item("attribute_id"), objDR.Item("name"), objElement.Name}
                DataGridViewMapping.Rows.Add(row)
            Next
        Next
        Me.SelectDeSelectMapping(False)
        DataGridViewMapping.AutoResizeColumn(2)
        DataGridViewMapping.AutoResizeColumn(3)




    End Sub

    Private Sub ButtonGenerateMapping_Click(sender As Object, e As EventArgs) Handles ButtonGenerateMapping.Click
        Dim objRow As DataGridViewRow
        Dim objGenerator As New IDEAGenerator()
        objGenerator.Repository = Me.Repository
        For Each objRow In DataGridViewMapping.Rows
            Dim objSource As EA.Attribute
            Dim objTarget As EA.Attribute
            If Not String.IsNullOrEmpty(objRow.Cells("source_attribute_id").Value) Then
                Dim sourceid As String = objRow.Cells("source_attribute_id").Value
                objSource = Repository.GetAttributeByID(sourceid)
                objTarget = Me.Repository.GetAttributeByID(objRow.Cells("target_attribute_id").Value)
                objGenerator.CreateConnectorForAttribute(objSource, objTarget)
            End If
        Next
        Me.Repository.ReloadDiagram(Me.Diagram.DiagramID)
    End Sub
End Class