﻿Imports System.Windows.Forms
Imports System.Drawing

Public Class FrmIdeaDiagram
    Private _Repository As EA.Repository
    Private strTargetIds As String = ""

    Public Property Repository() As EA.Repository
        Get
            Return _Repository
        End Get
        Set(ByVal value As EA.Repository)
            _Repository = value
        End Set
    End Property

    Private _Diagram As EA.Diagram
    Public Property Diagram() As EA.Diagram
        Get
            Return _Diagram
        End Get
        Set(ByVal value As EA.Diagram)
            _Diagram = value
            Me.LabelDiagramName.Text = _Diagram.Name
            Me.LabelMappingDiagramName.Text = _Diagram.Name
        End Set
    End Property
    Public Sub LoadElements()
        Dim objDS As DataSet
        Dim strSql As String
        strSql = String.Format("Select t_object.Object_ID as id, t_object.name from t_object, t_diagramobjects where t_object.Object_ID = t_diagramobjects.Object_ID and t_diagramobjects.Diagram_ID = {0} Order by t_object.Name", Me.Diagram.DiagramID)
        objDS = DLA2EAHelper.SQL2DataSet(strSql, Me.Repository)

        If objDS.Tables.Count > 0 Then
            Me.ListBoxElements.DataSource = objDS.Tables(1)
            Me.ListBoxElements.DisplayMember = "name"
            Me.ListBoxElements.ValueMember = "id"

            Me.ListBoxMappingElement.DataSource = objDS.Tables(1)
            Me.ListBoxMappingElement.DisplayMember = "name"
            Me.ListBoxMappingElement.ValueMember = "id"
            CreateMappingGrid()
        Else
            MsgBox("No elements on diagram", MsgBoxStyle.OkOnly)
            Me.Close()
        End If


    End Sub
    Private Sub SelectDeSelectMapping(state As Boolean)
        Dim i As Int16 = 0
        While i < ListBoxMappingElement.Items.Count
            ListBoxMappingElement.SetItemChecked(i, state)
            i += 1
        End While
    End Sub

    Private Sub SelectDeSelect(state As Boolean)
        Dim i As Int16 = 0
        While i < ListBoxElements.Items.Count
            ListBoxElements.SetItemChecked(i, state)
            i += 1
        End While
    End Sub

    Private Sub SelectToggle()
        Dim i As Int16 = 0
        While i < ListBoxElements.Items.Count
            ListBoxElements.SetItemChecked(i, (Not ListBoxElements.GetItemChecked(i)))
            i += 1
        End While
    End Sub

    Private Sub ButtonSelectAll_Click(sender As Object, e As EventArgs) Handles ButtonSelectAll.Click
        SelectDeSelect(True)
    End Sub
    Private Sub ButtonUnselectAll_Click(sender As Object, e As EventArgs) Handles ButtonUnselectAll.Click
        SelectDeSelect(False)
    End Sub

    Private Sub ButtonToggleAll_Click(sender As Object, e As EventArgs) Handles ButtonToggleAll.Click
        SelectToggle()
    End Sub

    Private Sub ButtonGenerate_Click(sender As Object, e As EventArgs) Handles ButtonGenerate.Click
        If IsNothing(Me.ListBoxType.SelectedItem) Then
            MsgBox("Target type not selected, select a target type first", MsgBoxStyle.OkOnly)
        Else

            Dim item As DataRowView
            Dim objNew As EA.Element
            Dim objElement As EA.Element
            Dim objGenerator As New IDEAGenerator()
            objGenerator.Repository = Me.Repository
            For Each item In Me.ListBoxElements.CheckedItems
                objElement = Repository.GetElementByID(item("id"))
                objNew = objGenerator.CreateElement(Me.TextBoxPrefix.Text & objElement.Name, Me.ListBoxType.SelectedItem.ToString(), objElement.PackageID)
                Dim objDS As DataSet
                Dim strSql As String
                strSql = String.Format("SELECT id as attribute_id, name FROM t_attribute WHERE object_id = {0} ORDER BY name", objElement.ElementID)
                objDS = DLA2EAHelper.SQL2DataSet(strSql, Me.Repository)
                If objDS.Tables.Count > 0 Then
                    Dim objDR As DataRow
                    For Each objDR In objDS.Tables(1).Rows
                        objGenerator.CopyAttribute(objElement, objNew, Me.ListBoxType.SelectedItem.ToString().ToUpper(), objDR("attribute_id"), Me.CheckBoxAttributeAssociation.Checked)
                        If Not Me.CheckBoxAttributeAssociation.Checked Then
                            objGenerator.CreateTraceAssociation(objElement, objNew)
                        End If
                    Next
                End If
            Next

            Me.Close()
        End If

    End Sub
    Private Sub CreateMappingGrid()
        'create a grid framework for mappings
        Me.DataGridViewMapping.ColumnCount = 3
        Me.DataGridViewMapping.Columns(0).Name = "source_attributeid"
        Me.DataGridViewMapping.Columns(1).Name = "source_attributename"
        Me.DataGridViewMapping.Columns(2).Name = "source_entityname"
        Me.DataGridViewMapping.Columns(0).Visible = False

        With DataGridViewMapping.ColumnHeadersDefaultCellStyle
            .BackColor = Color.Navy
            .ForeColor = Color.White
            .Font = New Font(DataGridViewMapping.Font, FontStyle.Bold)
        End With
        Dim chb As New DataGridViewCheckBoxColumn()
        'create a merger column for a merger entity
        chb.HeaderText = "Merge"
        chb.ToolTipText = "Merge one or more attributes to a merger class"
        chb.Name = "Merger"
        Me.DataGridViewMapping.Columns.Add(chb)
    End Sub
    Private Sub ButtonMappingSource_Click(sender As Object, e As EventArgs) Handles ButtonMappingSource.Click
        'extend the grid with the source elements
        Dim item As DataRowView
        Dim objElement As EA.Element
        Me.DataGridViewMapping.Rows.Clear()
        For Each item In Me.ListBoxMappingElement.CheckedItems
            objElement = Repository.GetElementByID(item("id"))
            Dim objDS As DataSet
            Dim strSql As String
            strSql = String.Format("SELECT ea_guid as attribute_id, name FROM t_attribute WHERE object_id = {0} ORDER BY name", objElement.ElementID)

            objDS = DLA2EAHelper.SQL2DataSet(strSql, Me.Repository)
            Dim objDR As DataRow
            For Each objDR In objDS.Tables(1).Rows
                Dim row As String()
                row = {objDR.Item("attribute_id"), objDR.Item("name"), objElement.Name, False}
                DataGridViewMapping.Rows.Add(row)
            Next
        Next
        'turn off selected elements in the mapping combobox
        Me.SelectDeSelectMapping(False)
        DataGridViewMapping.AutoResizeColumn(0)
        DataGridViewMapping.AutoResizeColumn(1)
    End Sub

    Private Sub ButtonMappingTarget_Click(sender As Object, e As EventArgs) Handles ButtonMappingTarget.Click
        'extend the grid with the target attributes in a combobox
        Dim item As DataRowView
        Dim cmb As New DataGridViewComboBoxColumn()

        If Me.DataGridViewMapping.Rows.Count = 0 Then
            MsgBox("Please select the source attributes first")
        Else
            'if there is already a column through it away
            If Me.DataGridViewMapping.ColumnCount > 5 Then
                Me.DataGridViewMapping.Columns.RemoveAt(4)
            End If
            cmb.HeaderText = "Target"
            cmb.ToolTipText = "Select the correct target attribute"
            cmb.Name = "target_attributeid"
            cmb.AutoComplete = True
            cmb.DisplayStyle = DataGridViewComboBoxDisplayStyle.ComboBox
            cmb.MaxDropDownItems = 10
            cmb.DefaultCellStyle = DataGridViewMapping.Columns(0).DefaultCellStyle
            Dim strElements As String = "-999"
            For Each item In Me.ListBoxMappingElement.CheckedItems
                strElements += ", " + item("id")
            Next
            Dim objDS As DataSet
            Dim strSql As String
            strSql = String.Format("SELECT t_attribute.ea_guid as attribute_id, t_attribute.name + ' (' + t_object.name + ')' as attrname FROM t_attribute, t_object WHERE t_attribute.object_id = t_object.object_id AND t_object.object_id IN( {0} ) ORDER BY 2", strElements)
            strSql = DLA2EAHelper.SQLForEAP(strSql, Me.Repository)
            objDS = DLA2EAHelper.SQL2DataSet(strSql, Me.Repository)
            If objDS.Tables.Count > 0 Then

                cmb.DataSource = objDS.Tables(1)
                cmb.DisplayMember = "attrname"
                cmb.ValueMember = "attribute_id"
                cmb.Width = 200

                Me.DataGridViewMapping.Columns.Add(cmb)
                DataGridViewMapping.AutoResizeColumn(3)

                SelectDeSelectMapping(False)
                Me.strTargetIds = ""
                Dim objDR As DataRow
                For Each objDR In objDS.Tables(1).Rows
                    strTargetIds += objDR.Item("attribute_id") + ", "
                Next
            End If
        End If

    End Sub
    Private Sub DataGridView1_DataError(ByVal sender As Object, ByVal e As DataGridViewDataErrorEventArgs) Handles DataGridViewMapping.DataError
        'deze laten staan anders krijgen we mogelijk foutmeldingen vanuit het besturingsysteem
    End Sub


    Private Sub ButtonGenerateMapping_Click(sender As Object, e As EventArgs) Handles ButtonGenerateMapping.Click
        Dim objRow As DataGridViewRow
        Dim objGenerator As New IDEAGenerator()
        Dim arrSleutels As New List(Of String())
        Dim objSource As EA.Attribute
        Dim objTarget As EA.Attribute
        Dim objMerger As EA.Element

        objGenerator.Repository = Me.Repository
        For Each objRow In DataGridViewMapping.Rows
            If Not String.IsNullOrEmpty(objRow.Cells("target_attributeid").Value) And objRow.ReadOnly = False Then
                If objRow.Cells("Merger").Value = False Then
                    'when it is a regular mapping create an association for the attributes
                    Dim sourceid As String = objRow.Cells("source_attributeid").Value
                    objSource = Repository.GetAttributeByGuid(sourceid)
                    objTarget = Me.Repository.GetAttributeByGuid(objRow.Cells("target_attributeid").Value)
                    objGenerator.CreateConnectorForAttribute(objSource, objTarget)
                Else
                    'when it is a merger first generate a list of keys for later processing
                    arrSleutels.Add({objRow.Cells("target_attributeid").Value, objRow.Cells("source_attributeid").Value})
                End If
            End If
        Next
        Dim strItem As String()
        For Each strItem In arrSleutels
            'for all the collected keys create mergers (one or more depending on the selection
            objTarget = Me.Repository.GetAttributeByGuid(strItem(0))
            objSource = Me.Repository.GetAttributeByGuid(strItem(1))
            Dim objPackage As EA.Package
            Dim objEleInPackage As EA.Element
            Dim blnFound As Boolean = False
            objPackage = Me.Repository.GetPackageByID(Me.Diagram.PackageID)
            For Each objEleInPackage In objPackage.Elements
                'searh for mergers
                If objEleInPackage.Alias = objTarget.AttributeGUID Then
                    objMerger = objEleInPackage
                    blnFound = True
                    Exit For
                End If
            Next
            If blnFound = False Then
                'if the merger is not found then create it
                objMerger = objGenerator.CreateElement("Merger " + objTarget.Name, "Class", Me.Diagram.PackageID)
                objMerger.Alias = objTarget.AttributeGUID
                objMerger.Update()
                objGenerator.CopyAttribute(Me.Repository.GetElementByID(objTarget.ParentID), objMerger, objTarget.Type, Repository.GetAttributeByGuid(strItem(0)).AttributeID, True, "Source -> Destination")
                Dim objDO As EA.DiagramObject
                objDO = Me.Diagram.DiagramObjects.AddNew(objMerger.Name, "")
                objDO.ElementID = objMerger.ElementID
                objDO.top = Me.Diagram.PageHeight / 2
                objDO.left = Me.Diagram.PageWidth / 2
                objDO.Update()
            End If
            'the merger is created or found so we gonna connect the attributes to it
            'Omdat we met guids werken een ingewikkelder aanroep van het id
            objGenerator.CopyAttribute(Me.Repository.GetElementByID(objSource.ParentID), objMerger, objSource.Type, Repository.GetAttributeByGuid(strItem(1)).AttributeID, True, "Destination -> Source")
            objMerger.Update()
        Next
        Me.Repository.ReloadDiagram(Me.Diagram.DiagramID)

    End Sub



    Private Sub ButtonLoadMappings_Click(sender As Object, e As EventArgs) Handles ButtonLoadMappings.Click
        Dim strSourceID As String
        Dim strLinks As String
        Dim objDL As EA.DiagramLink
        Dim intTeller As Int16
        Try
            For intTeller = 0 To DataGridViewMapping.Rows.Count - 1
                strSourceID = DataGridViewMapping.Rows(intTeller).Cells("source_attributeid").Value
                For Each objDL In Me.Diagram.DiagramLinks
                    strLinks = Me.Repository.GetConnectorByID(objDL.ConnectorID).StyleEx
                    strLinks = strLinks.Replace("LFEP=", "").Replace("LFSP=", "").Replace("L;", "R;")
                    Dim arrLinks As String()
                    arrLinks = strLinks.Split("R;")
                    If arrLinks.Length > 1 Then
                        Dim strKey As String = ""
                        Dim cmb As DataGridViewComboBoxCell = CType(DataGridViewMapping.Rows(intTeller).Cells("target_attributeid"), DataGridViewComboBoxCell)
                        If arrLinks(0).Contains(strSourceID) Then
                            strKey = arrLinks(1).Replace(";", "").Trim()
                            If Me.strTargetIds.IndexOf(strKey) >= 0 Then
                                cmb.Value = strKey
                                DataGridViewMapping.Rows(intTeller).ReadOnly = True
                                DataGridViewMapping.Rows(intTeller).DefaultCellStyle.BackColor = Color.LightGray
                            End If

                        End If
                        If arrLinks(1).Contains(strSourceID) Then
                            strKey = arrLinks(0).Replace(";", "").Trim()
                            If Me.strTargetIds.IndexOf(strKey) >= 0 Then
                                cmb.Value = strKey
                                DataGridViewMapping.Rows(intTeller).ReadOnly = True
                                DataGridViewMapping.Rows(intTeller).DefaultCellStyle.BackColor = Color.LightGray
                            End If
                        End If
                    End If
                Next
            Next
        Catch ex As Exception

        End Try

    End Sub
End Class