﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmIdeaDiagram
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ButtonUnselectAll = New System.Windows.Forms.Button()
        Me.ButtonToggleAll = New System.Windows.Forms.Button()
        Me.ButtonSelectAll = New System.Windows.Forms.Button()
        Me.ListBoxElements = New System.Windows.Forms.CheckedListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LabelDiagramName = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBoxPrefix = New System.Windows.Forms.TextBox()
        Me.ListBoxType = New System.Windows.Forms.ListBox()
        Me.ButtonGenerate = New System.Windows.Forms.Button()
        Me.CheckBoxAttributeAssociation = New System.Windows.Forms.CheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.ButtonLoadMappings = New System.Windows.Forms.Button()
        Me.ButtonGenerateMapping = New System.Windows.Forms.Button()
        Me.ButtonMappingTarget = New System.Windows.Forms.Button()
        Me.ButtonMappingSource = New System.Windows.Forms.Button()
        Me.DataGridViewMapping = New System.Windows.Forms.DataGridView()
        Me.ListBoxMappingElement = New System.Windows.Forms.CheckedListBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.LabelMappingDiagramName = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridViewMapping, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonUnselectAll
        '
        Me.ButtonUnselectAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ButtonUnselectAll.Location = New System.Drawing.Point(265, 594)
        Me.ButtonUnselectAll.Margin = New System.Windows.Forms.Padding(4)
        Me.ButtonUnselectAll.Name = "ButtonUnselectAll"
        Me.ButtonUnselectAll.Size = New System.Drawing.Size(100, 28)
        Me.ButtonUnselectAll.TabIndex = 21
        Me.ButtonUnselectAll.Text = "Unselect All"
        Me.ButtonUnselectAll.UseVisualStyleBackColor = True
        '
        'ButtonToggleAll
        '
        Me.ButtonToggleAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ButtonToggleAll.Location = New System.Drawing.Point(141, 594)
        Me.ButtonToggleAll.Margin = New System.Windows.Forms.Padding(4)
        Me.ButtonToggleAll.Name = "ButtonToggleAll"
        Me.ButtonToggleAll.Size = New System.Drawing.Size(100, 28)
        Me.ButtonToggleAll.TabIndex = 20
        Me.ButtonToggleAll.Text = "Toggle"
        Me.ButtonToggleAll.UseVisualStyleBackColor = True
        '
        'ButtonSelectAll
        '
        Me.ButtonSelectAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ButtonSelectAll.Location = New System.Drawing.Point(20, 594)
        Me.ButtonSelectAll.Margin = New System.Windows.Forms.Padding(4)
        Me.ButtonSelectAll.Name = "ButtonSelectAll"
        Me.ButtonSelectAll.Size = New System.Drawing.Size(100, 28)
        Me.ButtonSelectAll.TabIndex = 19
        Me.ButtonSelectAll.Text = "Select All"
        Me.ButtonSelectAll.UseVisualStyleBackColor = True
        '
        'ListBoxElements
        '
        Me.ListBoxElements.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ListBoxElements.FormattingEnabled = True
        Me.ListBoxElements.Location = New System.Drawing.Point(20, 121)
        Me.ListBoxElements.Margin = New System.Windows.Forms.Padding(4)
        Me.ListBoxElements.Name = "ListBoxElements"
        Me.ListBoxElements.Size = New System.Drawing.Size(344, 429)
        Me.ListBoxElements.TabIndex = 18
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(20, 101)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(124, 17)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Selected elements"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(20, 20)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(118, 17)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Selected diagram"
        '
        'LabelDiagramName
        '
        Me.LabelDiagramName.AutoSize = True
        Me.LabelDiagramName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelDiagramName.Location = New System.Drawing.Point(20, 50)
        Me.LabelDiagramName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelDiagramName.Name = "LabelDiagramName"
        Me.LabelDiagramName.Size = New System.Drawing.Size(148, 24)
        Me.LabelDiagramName.TabIndex = 22
        Me.LabelDiagramName.Text = "Diagram Name"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(381, 20)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 17)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Prefix"
        '
        'TextBoxPrefix
        '
        Me.TextBoxPrefix.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxPrefix.Location = New System.Drawing.Point(452, 20)
        Me.TextBoxPrefix.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBoxPrefix.Name = "TextBoxPrefix"
        Me.TextBoxPrefix.Size = New System.Drawing.Size(296, 22)
        Me.TextBoxPrefix.TabIndex = 24
        '
        'ListBoxType
        '
        Me.ListBoxType.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListBoxType.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.ListBoxType.FormattingEnabled = True
        Me.ListBoxType.ItemHeight = 16
        Me.ListBoxType.Items.AddRange(New Object() {"Class", "Interface", "Table"})
        Me.ListBoxType.Location = New System.Drawing.Point(384, 72)
        Me.ListBoxType.Margin = New System.Windows.Forms.Padding(4)
        Me.ListBoxType.Name = "ListBoxType"
        Me.ListBoxType.Size = New System.Drawing.Size(363, 68)
        Me.ListBoxType.TabIndex = 25
        '
        'ButtonGenerate
        '
        Me.ButtonGenerate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonGenerate.Location = New System.Drawing.Point(464, 583)
        Me.ButtonGenerate.Margin = New System.Windows.Forms.Padding(4)
        Me.ButtonGenerate.Name = "ButtonGenerate"
        Me.ButtonGenerate.Size = New System.Drawing.Size(285, 39)
        Me.ButtonGenerate.TabIndex = 26
        Me.ButtonGenerate.Text = "Generate elements and attributes"
        Me.ButtonGenerate.UseVisualStyleBackColor = True
        '
        'CheckBoxAttributeAssociation
        '
        Me.CheckBoxAttributeAssociation.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CheckBoxAttributeAssociation.AutoSize = True
        Me.CheckBoxAttributeAssociation.Checked = True
        Me.CheckBoxAttributeAssociation.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBoxAttributeAssociation.Location = New System.Drawing.Point(387, 164)
        Me.CheckBoxAttributeAssociation.Margin = New System.Windows.Forms.Padding(4)
        Me.CheckBoxAttributeAssociation.Name = "CheckBoxAttributeAssociation"
        Me.CheckBoxAttributeAssociation.Size = New System.Drawing.Size(203, 21)
        Me.CheckBoxAttributeAssociation.TabIndex = 27
        Me.CheckBoxAttributeAssociation.Text = "Create attribute association"
        Me.CheckBoxAttributeAssociation.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.BackColor = System.Drawing.Color.LemonChiffon
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Location = New System.Drawing.Point(385, 458)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(367, 92)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "With this option you can generate new items of a type based on the elements found" &
    " in the selected diagram in one easy step."
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(773, 671)
        Me.TabControl1.TabIndex = 29
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.LightGray
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.ListBoxElements)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.CheckBoxAttributeAssociation)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.ButtonGenerate)
        Me.TabPage1.Controls.Add(Me.ButtonSelectAll)
        Me.TabPage1.Controls.Add(Me.ListBoxType)
        Me.TabPage1.Controls.Add(Me.ButtonToggleAll)
        Me.TabPage1.Controls.Add(Me.TextBoxPrefix)
        Me.TabPage1.Controls.Add(Me.ButtonUnselectAll)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.LabelDiagramName)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage1.Size = New System.Drawing.Size(765, 642)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Generate"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.LightGray
        Me.TabPage2.Controls.Add(Me.ButtonLoadMappings)
        Me.TabPage2.Controls.Add(Me.ButtonGenerateMapping)
        Me.TabPage2.Controls.Add(Me.ButtonMappingTarget)
        Me.TabPage2.Controls.Add(Me.ButtonMappingSource)
        Me.TabPage2.Controls.Add(Me.DataGridViewMapping)
        Me.TabPage2.Controls.Add(Me.ListBoxMappingElement)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.LabelMappingDiagramName)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage2.Size = New System.Drawing.Size(765, 642)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Mapping"
        '
        'ButtonLoadMappings
        '
        Me.ButtonLoadMappings.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonLoadMappings.Location = New System.Drawing.Point(569, 60)
        Me.ButtonLoadMappings.Name = "ButtonLoadMappings"
        Me.ButtonLoadMappings.Size = New System.Drawing.Size(120, 30)
        Me.ButtonLoadMappings.TabIndex = 30
        Me.ButtonLoadMappings.Text = "Load Mappings"
        Me.ButtonLoadMappings.UseVisualStyleBackColor = True
        '
        'ButtonGenerateMapping
        '
        Me.ButtonGenerateMapping.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonGenerateMapping.Location = New System.Drawing.Point(564, 15)
        Me.ButtonGenerateMapping.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ButtonGenerateMapping.Name = "ButtonGenerateMapping"
        Me.ButtonGenerateMapping.Size = New System.Drawing.Size(193, 33)
        Me.ButtonGenerateMapping.TabIndex = 29
        Me.ButtonGenerateMapping.Text = "Generate mappings"
        Me.ButtonGenerateMapping.UseVisualStyleBackColor = True
        '
        'ButtonMappingTarget
        '
        Me.ButtonMappingTarget.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonMappingTarget.Location = New System.Drawing.Point(564, 116)
        Me.ButtonMappingTarget.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ButtonMappingTarget.Name = "ButtonMappingTarget"
        Me.ButtonMappingTarget.Size = New System.Drawing.Size(125, 33)
        Me.ButtonMappingTarget.TabIndex = 28
        Me.ButtonMappingTarget.Text = "To target"
        Me.ButtonMappingTarget.UseVisualStyleBackColor = True
        '
        'ButtonMappingSource
        '
        Me.ButtonMappingSource.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ButtonMappingSource.Location = New System.Drawing.Point(80, 116)
        Me.ButtonMappingSource.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ButtonMappingSource.Name = "ButtonMappingSource"
        Me.ButtonMappingSource.Size = New System.Drawing.Size(125, 33)
        Me.ButtonMappingSource.TabIndex = 27
        Me.ButtonMappingSource.Text = "To source"
        Me.ButtonMappingSource.UseVisualStyleBackColor = True
        '
        'DataGridViewMapping
        '
        Me.DataGridViewMapping.AllowUserToAddRows = False
        Me.DataGridViewMapping.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridViewMapping.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewMapping.Location = New System.Drawing.Point(-4, 162)
        Me.DataGridViewMapping.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DataGridViewMapping.Name = "DataGridViewMapping"
        Me.DataGridViewMapping.RowTemplate.Height = 24
        Me.DataGridViewMapping.Size = New System.Drawing.Size(773, 478)
        Me.DataGridViewMapping.TabIndex = 26
        '
        'ListBoxMappingElement
        '
        Me.ListBoxMappingElement.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ListBoxMappingElement.FormattingEnabled = True
        Me.ListBoxMappingElement.Location = New System.Drawing.Point(212, 15)
        Me.ListBoxMappingElement.Margin = New System.Windows.Forms.Padding(4)
        Me.ListBoxMappingElement.Name = "ListBoxMappingElement"
        Me.ListBoxMappingElement.Size = New System.Drawing.Size(344, 123)
        Me.ListBoxMappingElement.TabIndex = 24
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 15)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(118, 17)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "Selected diagram"
        '
        'LabelMappingDiagramName
        '
        Me.LabelMappingDiagramName.AutoSize = True
        Me.LabelMappingDiagramName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMappingDiagramName.Location = New System.Drawing.Point(9, 41)
        Me.LabelMappingDiagramName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelMappingDiagramName.Name = "LabelMappingDiagramName"
        Me.LabelMappingDiagramName.Size = New System.Drawing.Size(148, 24)
        Me.LabelMappingDiagramName.TabIndex = 25
        Me.LabelMappingDiagramName.Text = "Diagram Name"
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(381, 50)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(81, 17)
        Me.Label6.TabIndex = 29
        Me.Label6.Text = "Target type"
        '
        'FrmIdeaDiagram
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(773, 671)
        Me.Controls.Add(Me.TabControl1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MinimumSize = New System.Drawing.Size(87, 75)
        Me.Name = "FrmIdeaDiagram"
        Me.Text = "IDEA Diagram Helper"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DataGridViewMapping, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ButtonUnselectAll As System.Windows.Forms.Button
    Friend WithEvents ButtonToggleAll As System.Windows.Forms.Button
    Friend WithEvents ButtonSelectAll As System.Windows.Forms.Button
    Friend WithEvents ListBoxElements As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LabelDiagramName As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBoxPrefix As System.Windows.Forms.TextBox
    Friend WithEvents ListBoxType As System.Windows.Forms.ListBox
    Friend WithEvents ButtonGenerate As System.Windows.Forms.Button
    Friend WithEvents CheckBoxAttributeAssociation As System.Windows.Forms.CheckBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents ButtonGenerateMapping As System.Windows.Forms.Button
    Friend WithEvents ButtonMappingTarget As System.Windows.Forms.Button
    Friend WithEvents ButtonMappingSource As System.Windows.Forms.Button
    Friend WithEvents DataGridViewMapping As System.Windows.Forms.DataGridView
    Friend WithEvents ListBoxMappingElement As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents LabelMappingDiagramName As System.Windows.Forms.Label
    Friend WithEvents ButtonLoadMappings As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
