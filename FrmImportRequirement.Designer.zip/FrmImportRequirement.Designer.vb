﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmImportRequirement
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TextBoxTableNo = New System.Windows.Forms.TextBox()
        Me.DataGridViewExcel = New System.Windows.Forms.DataGridView()
        Me.ButtonLoad = New System.Windows.Forms.Button()
        Me.ButtonSelect = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBoxExcelFile = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBoxConnection = New System.Windows.Forms.TextBox()
        Me.TextBoxResult = New System.Windows.Forms.TextBox()
        Me.OpenExcelFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.ButtonImport = New System.Windows.Forms.Button()
        CType(Me.DataGridViewExcel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBoxTableNo
        '
        Me.TextBoxTableNo.Location = New System.Drawing.Point(453, 43)
        Me.TextBoxTableNo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBoxTableNo.Name = "TextBoxTableNo"
        Me.TextBoxTableNo.Size = New System.Drawing.Size(57, 22)
        Me.TextBoxTableNo.TabIndex = 19
        Me.TextBoxTableNo.Text = "0"
        '
        'DataGridViewExcel
        '
        Me.DataGridViewExcel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridViewExcel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewExcel.Location = New System.Drawing.Point(-4, 109)
        Me.DataGridViewExcel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.DataGridViewExcel.Name = "DataGridViewExcel"
        Me.DataGridViewExcel.RowTemplate.Height = 24
        Me.DataGridViewExcel.Size = New System.Drawing.Size(808, 439)
        Me.DataGridViewExcel.TabIndex = 18
        '
        'ButtonLoad
        '
        Me.ButtonLoad.Enabled = False
        Me.ButtonLoad.Location = New System.Drawing.Point(416, 2)
        Me.ButtonLoad.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ButtonLoad.Name = "ButtonLoad"
        Me.ButtonLoad.Size = New System.Drawing.Size(92, 27)
        Me.ButtonLoad.TabIndex = 17
        Me.ButtonLoad.Text = "Load data"
        Me.ButtonLoad.UseVisualStyleBackColor = True
        '
        'ButtonSelect
        '
        Me.ButtonSelect.Location = New System.Drawing.Point(312, 2)
        Me.ButtonSelect.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ButtonSelect.Name = "ButtonSelect"
        Me.ButtonSelect.Size = New System.Drawing.Size(100, 27)
        Me.ButtonSelect.TabIndex = 16
        Me.ButtonSelect.Text = "Select file"
        Me.ButtonSelect.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(5, -24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 17)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Excel file"
        '
        'TextBoxExcelFile
        '
        Me.TextBoxExcelFile.Location = New System.Drawing.Point(8, 4)
        Me.TextBoxExcelFile.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBoxExcelFile.Name = "TextBoxExcelFile"
        Me.TextBoxExcelFile.Size = New System.Drawing.Size(299, 22)
        Me.TextBoxExcelFile.TabIndex = 14
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(416, -28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(114, 17)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Connectionstring"
        '
        'TextBoxConnection
        '
        Me.TextBoxConnection.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxConnection.Location = New System.Drawing.Point(516, 4)
        Me.TextBoxConnection.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBoxConnection.Multiline = True
        Me.TextBoxConnection.Name = "TextBoxConnection"
        Me.TextBoxConnection.Size = New System.Drawing.Size(275, 67)
        Me.TextBoxConnection.TabIndex = 12
        '
        'TextBoxResult
        '
        Me.TextBoxResult.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxResult.BackColor = System.Drawing.SystemColors.Control
        Me.TextBoxResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBoxResult.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextBoxResult.Location = New System.Drawing.Point(8, 79)
        Me.TextBoxResult.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBoxResult.Name = "TextBoxResult"
        Me.TextBoxResult.Size = New System.Drawing.Size(785, 22)
        Me.TextBoxResult.TabIndex = 20
        '
        'OpenExcelFileDialog
        '
        Me.OpenExcelFileDialog.FileName = "OpenFileDialog1"
        '
        'ButtonImport
        '
        Me.ButtonImport.Location = New System.Drawing.Point(8, 42)
        Me.ButtonImport.Name = "ButtonImport"
        Me.ButtonImport.Size = New System.Drawing.Size(102, 29)
        Me.ButtonImport.TabIndex = 21
        Me.ButtonImport.Text = "Import"
        Me.ButtonImport.UseVisualStyleBackColor = True
        '
        'FrmImportRequirement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 520)
        Me.Controls.Add(Me.ButtonImport)
        Me.Controls.Add(Me.TextBoxResult)
        Me.Controls.Add(Me.TextBoxTableNo)
        Me.Controls.Add(Me.DataGridViewExcel)
        Me.Controls.Add(Me.ButtonLoad)
        Me.Controls.Add(Me.ButtonSelect)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TextBoxExcelFile)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBoxConnection)
        Me.Name = "FrmImportRequirement"
        Me.Text = "FrmImportRequirement"
        CType(Me.DataGridViewExcel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBoxTableNo As System.Windows.Forms.TextBox
    Friend WithEvents DataGridViewExcel As System.Windows.Forms.DataGridView
    Friend WithEvents ButtonLoad As System.Windows.Forms.Button
    Friend WithEvents ButtonSelect As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBoxExcelFile As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBoxConnection As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxResult As System.Windows.Forms.TextBox
    Friend WithEvents OpenExcelFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ButtonImport As System.Windows.Forms.Button
End Class
