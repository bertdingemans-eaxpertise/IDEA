﻿Imports System.Data.OleDb

Public Class FrmImportRequirement
    Protected strTable As String
    Protected objRepo As EA.Repository
    Protected objDT As DataTable

    Public Sub SetRepository(oRep As EA.Repository)
        Me.objRepo = oRep

    End Sub
    Private Sub ButtonSelect_Click(sender As Object, e As EventArgs) Handles ButtonSelect.Click
        Me.OpenExcelFileDialog.Filter = "xlsx files (*.xlsx)|*.xlsx|All files (*.*)|*.*"
        If OpenExcelFileDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            Me.TextBoxExcelFile.Text = OpenExcelFileDialog.FileName
            Dim strConnect As String = Me.TextBoxConnection.Text
            Me.TextBoxConnection.Text = strConnect.Replace("[FILE]", Me.TextBoxExcelFile.Text)
            Me.ButtonLoad.Enabled = True

        End If
    End Sub

    Private Sub ButtonLoad_Click(sender As Object, e As EventArgs) Handles ButtonLoad.Click
        LoadTableName()
        LoadData()
    End Sub

    Private Sub LoadTableName()
        Dim objCon As OleDb.OleDbConnection

        Try
            objCon = New OleDb.OleDbConnection(Me.TextBoxConnection.Text)
            objCon.Open()

            Dim DT As DataTable
            DT = objCon.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
            Me.strTable = "[" & DT.Rows(Convert.ToInt16(Me.TextBoxTableNo.Text)).Item("TABLE_NAME").ToString() & "]"

            objCon.Close()
        Catch ex As Exception
            TextBoxResult.Text += ex.Message + vbCrLf
        End Try
    End Sub

    Private Sub LoadData(sSql As String)
        Dim objCon As OleDb.OleDbConnection

        Try
            objCon = New OleDb.OleDbConnection(Me.TextBoxConnection.Text)
            objCon.Open()

            Dim objDS As New DataSet
            Dim objDA As New OleDb.OleDbDataAdapter(sSql, objCon)
            objDA.Fill(objDS, "Objecten")

            Me.objDT = objDS.Tables("Objecten")

            DataGridViewExcel.DataSource = objDS
            DataGridViewExcel.DataMember = "Objecten"

            objCon.Close()
            TextBoxResult.Text += "Data Loaded!" + vbCrLf
        Catch ex As Exception
            TextBoxResult.Text += ex.Message + vbCrLf
        End Try
    End Sub
    Private Sub LoadData()
        LoadData("SELECT * FROM " & strTable)
    End Sub

    Private Sub FrmImportRequirement_Load(sender As Object, e As EventArgs) Handles Me.Load
        Me.OpenExcelFileDialog.FileName = ""
        Me.TextBoxConnection.Text = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=[FILE];Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
    End Sub

    Private Sub ButtonRequirements_Click(sender As Object, e As EventArgs) Handles ButtonImport.Click
        Dim objProces As New TEADataSet2Repository()
        Dim objRow As DataRow
        objProces.Repository = Me.objRepo
        'For Each objRow In Me.objDT.Rows
        '    Dim objElement As EA.Element
        '    If Not IsDBNull(objRow.Item("Domein")) Then
        '        If DLA2EAHelper.CheckUniqueElement(objRow.Item("Domein"), "ArchiMate_ApplicationFunction", Me.objRepo) Then
        '            objElement = objProces.AddElement("ArchiMate_ApplicationFunction", objRow.Item("Domein"), "")
        '            objElement.Update()
        '        End If
        '    End If
        'Next

        For Each objRow In Me.objDT.Rows
            Dim objElement As EA.Element
            Dim objDomein As EA.Element

            If Not IsDBNull(objRow.Item("Requirement")) Then
                Dim strType As String
                If Not IsDBNull(objRow.Item("Type")) Then
                    strType = objRow.Item("Type")

                    If DLA2EAHelper.CheckUniqueElement(objRow.Item("Requirement"), "ArchiMate_" & strType, Me.objRepo) Then
                        Dim strNotes As String = ""
                        If Not IsDBNull(objRow.Item("Opmerking")) Then
                            strNotes = objRow.Item("Opmerking")
                        End If

                        objElement = objProces.AddElement("ArchiMate_" & strType, objRow.Item("Requirement"), strNotes)
                        objElement.Alias = objRow.Item("SubID")
                        objElement.Update()
                        If Not IsDBNull(objRow.Item("MoSCoW")) Then
                            Dim objTV As EA.TaggedValue
                            objTV = objElement.TaggedValues.AddNew("MoSCoW", "")
                            objTV.Value = objRow.Item("MoSCoW")
                            objTV.Update()
                        End If
                        objElement.Update()
                    End If

                    If Not IsDBNull(objRow.Item("Domein")) Then
                        If DLA2EAHelper.CheckUniqueElement(objRow.Item("Domein"), "ArchiMate_ApplicationFunction", Me.objRepo) Then
                            objDomein = objProces.AddElement("ArchiMate_ApplicationFunction", objRow.Item("Domein"), "")
                            objDomein.Update()
                        Else
                            objDomein = objProces.FindElement(objRow.Item("Domein"), "ArchiMate_ApplicationFunction")
                        End If
                        Dim objConnector As EA.Connector
                        objConnector = objProces.AddConnector(objElement, objDomein, "Association")
                        objConnector.Update()
                    End If

                End If

            End If
        Next
        TextBoxResult.Text = "Entities loaded"
    End Sub
End Class