Imports System.IO
Imports System.Text

''' <summary>
''' Class for the HTML generator. Various functions to generate HTML pages and
''' snippets from the elements in the repository
''' </summary>
Public Class HTMLPublicator
    Const ForReading = 1, ForWriting = 2

    Protected sPath As String
    Protected sHome As String
    Protected sTemplate As String
    Protected oSBSiteMap As StringBuilder
    Protected oSBSideBar As StringBuilder
    Protected oALDiagrams As New ArrayList()
    Protected blnCreatePDF As Boolean = False
    Protected blnCompositeClickable As Boolean = False
    Private blnDiagElemCombined As Boolean = True
    Private _Rep As EA.Repository
    ''' <summary>
    ''' Create a pdf of the packages that are processed and contain diagrams
    ''' </summary>
    ''' <returns></returns>
    Public Property CreatePDF() As Boolean
        Get
            Return blnCreatePDF
        End Get
        Set(ByVal value As Boolean)
            blnCreatePDF = value
        End Set
    End Property

    Private _Templates As HTMLTemplates
    Public Property Templates() As HTMLTemplates
        Get
            Return _Templates
        End Get
        Set(ByVal value As HTMLTemplates)
            _Templates = value
        End Set
    End Property

    Public Property CompositeClickable() As Boolean
        Get
            Return blnCompositeClickable
        End Get
        Set(ByVal value As Boolean)
            blnCompositeClickable = value
        End Set
    End Property
    ''' <summary>
    ''' Combine the diagram and the elements in one html page (or not)
    ''' </summary>
    ''' <returns></returns>
    Public Property DiagElemCombined() As Boolean
        Get
            Return blnDiagElemCombined
        End Get
        Set(ByVal value As Boolean)
            blnDiagElemCombined = value
        End Set
    End Property
    Public Property Repository() As EA.Repository
        Get
            Return _Rep
        End Get
        Set(ByVal value As EA.Repository)
            _Rep = value
        End Set
    End Property
    ''' <summary>
    ''' Check if the diagram is already processed or not (for cross references)
    ''' </summary>
    ''' <param name="ID">Id of the diagram</param>
    ''' <returns></returns>
    Private Function CheckDiagram(ByVal ID As String) As Boolean
        Return Me.oALDiagrams.Contains(ID)
    End Function
    ''' <summary>
    ''' Check if a diagram is already processed by the publisher and if not add it to the list of ready to process diagrams
    ''' </summary>
    ''' <param name="ID">ID of the diagram</param>
    ''' <returns></returns>
    Private Function CheckAndAddDiagram(ByVal ID As String) As Boolean
        If CheckDiagram(ID) = False Then
            Me.oALDiagrams.Add(ID)
            Me.Repository.WriteOutput("IDEA", "Diagram" + ID + " added to Array", 0)
            Return True
        Else
            Return False
        End If
    End Function
    ''' <summary>
    ''' Check if a diagram is processed and if so remove it from the list of to be processed diagrams
    ''' </summary>
    ''' <param name="ID"></param>
    ''' <returns></returns>
    Private Function CheckAndRemoveDiagram(ByVal ID As String) As Boolean
        If CheckDiagram(ID) = True Then
            Me.oALDiagrams.Remove(ID)
            Me.Repository.WriteOutput("IDEA", "Diagram" + ID + " Removed from Array", 0)
            Return True
        Else
            Return False
        End If
    End Function

    Public Sub New()
        'Definieer de globale variabelen en objecten
        sPath = My.Settings.HTMLPath
        sTemplate = "<html><head></head><body>#content#</body></html>"
        ReadHTMLTemplate(sPath + "\" + My.Settings.HTMLTemplate)
        Me.oSBSiteMap = New StringBuilder("")
        Me.oSBSideBar = New StringBuilder("")
        Me.oSBSiteMap.Append("<UL>")

    End Sub
    ''' <summary>
    ''' Read the template from a template file on the disk
    ''' </summary>
    ''' <param name="sTemplateFile">Name of the template file</param>
    Public Sub ReadHTMLTemplate(ByVal sTemplateFile As String)
        If File.Exists(sTemplateFile) Then
            Me.sTemplate = File.ReadAllText(sTemplateFile)
        End If
    End Sub
    ''' <summary>
    ''' Create a html href tag from the filename and the title
    ''' </summary>
    ''' <param name="sTitel">title of the hyperlink</param>
    ''' <param name="sURL">url to link to</param>
    ''' <returns></returns>
    Public Function MaakURL(ByVal sTitel As String, ByVal sURL As String) As String
        'Maak een url voor een lijst of overzicht 
        Dim oRow As DataRow
        oRow = Me._Templates.GetRowByName("Default_url")
        Dim sText As String = oRow("template_body")
        Return sText.Replace("#url#", sURL).Replace("#title#", sTitel)
    End Function
    ''' <summary>
    ''' Write the processed string to a file and do some processing for the tags
    ''' </summary>
    ''' <param name="sNaam">Name of the file</param>
    ''' <param name="sContent">html content</param>
    Public Sub Export2HTML(ByVal sNaam As String, ByVal sContent As String)
        'Export content naar een htmlfile gebaseerd op een constante in het templatebased on the constant of the path 
        Dim sValue As String

        sValue = sTemplate.Replace("#content#", sContent)
        'when a homepage is defined this is added too
        sValue = sValue.Replace("#home", sHome)
        If Me.oSBSideBar.Length > 0 Then
            Me.oSBSideBar.Insert(0, "<h3>Context menu</h3>")
        End If
        'sidebar for the links to the composite diagrams
        sValue = sValue.Replace("#sidebar#", Me.oSBSideBar.ToString())
        Me.oSBSideBar.Clear()
        File.WriteAllText(FullFileName(sPath, sNaam), sValue)
        Repository.WriteOutput("IDEA", FullFileName(sPath, sNaam) + " Is created", 0)
    End Sub
    Public Shared Function FullFileName(ByVal sPath As String, ByVal sNaam As String) As String
        Return sPath & sNaam & ".html"
    End Function
    Public Sub PubliceerRootPackage(ByVal oPkg As EA.Package)
        'Voor de zekerheid als de root anders verwerkt gaat worden
        sHome = "package" + oPkg.PackageID.ToString() + ".html"
        PubliceerPackage(oPkg)
    End Sub
    ''' <summary>
    ''' Write the diagram to disk as a png file on a standardized location
    ''' </summary>
    ''' <param name="iDiagram"></param>
    Public Sub SaveDiagramImage(ByVal iDiagram As Integer)
        'Schrijf diagram weg naar een plaatje 
        Dim objProject As EA.Project
        objProject = Repository.GetProjectInterface()
        Repository.OpenDiagram(iDiagram)
        objProject.SaveDiagramImageToFile(sPath + "diagram" + iDiagram.ToString() + ".png")
        Repository.CloseDiagram(iDiagram)
    End Sub
    ''' <summary>
    ''' Create a sitemap url for a package or diagram. With diagram you can define a tree like structure
    ''' </summary>
    ''' <param name="sURL"></param>
    ''' <param name="bNiveau"></param>
    Public Sub MaakSiteMapURL(ByVal sURL As String, ByVal bNiveau As String)
        'Opbouwen van de sitemap met URLs packages krijgen een h3
        If bNiveau = True Then
            oSBSiteMap.Append("<strong>")
        End If
        oSBSiteMap.Append("<li>" + sURL + "</li>")
        If bNiveau = True Then
            oSBSiteMap.Append("</strong>")
        End If

    End Sub

    Public Function PubliceerListPackages(oCol As EA.Collection) As String
        Dim oPackage As EA.Package
        Dim sTemplate_Body As String
        Dim oRow As DataRow
        If oCol.Count > 0 Then
            oRow = Me._Templates.GetRowByName("List_Packages")
            sTemplate_Body = ""
            For Each oPackage In oCol
                PubliceerPackage(oPackage)
                sTemplate_Body += oRow("Template_Body").Replace("#id#", oPackage.PackageID).Replace("#name#", oPackage.Name).Replace("#notes#", oPackage.Notes)
            Next
            Return oRow("Template_Header") + sTemplate_Body + oRow("Template_Footer")
        Else
            Return ""
        End If

    End Function

    Public Function PubliceerListDiagrams(oCol As EA.Collection) As String
        Dim oDiagram As EA.Diagram
        Dim sTemplate_Body As String
        Dim oRow As DataRow
        If oCol.Count > 0 Then
            oRow = Me._Templates.GetRowByName("List_Diagrams")
            sTemplate_Body = ""
            For Each oDiagram In oCol
                PubliceerDiagram(oDiagram)
                sTemplate_Body += oRow("Template_Body").Replace("#id#", oDiagram.DiagramID).Replace("#name#", oDiagram.Name).Replace("#notes#", oDiagram.Notes)
            Next
            Return oRow("Template_Header") + sTemplate_Body + oRow("Template_Footer")
        Else
            Return ""
        End If

    End Function

    Public Function PubliceerListElements(oCol As EA.Collection) As String
        Dim oElement As EA.Element
        Dim sTemplate_Body As String
        Dim oRow As DataRow
        If oCol.Count > 0 Then
            oRow = Me._Templates.GetRowByName("List_Elements")
            sTemplate_Body = ""
            For Each oElement In oCol
                'PubliceerElement(oDiagram)
                sTemplate_Body += oRow("Template_Body").Replace("#id#", oElement.ElementID).Replace("#name#", oElement.Name).Replace("#notes#", oElement.Notes)
            Next
            Return oRow("Template_Header") + sTemplate_Body + oRow("Template_Footer")
        Else
            Return ""
        End If

    End Function
    ''' <summary>
    ''' Publish a package to html
    ''' </summary>
    ''' <param name="oPkg">Object of the package to process</param>
    ''' 
    Public Sub PubliceerPackage(ByVal oPkg As EA.Package)

        Dim sTemplate As String
        sTemplate = Me._Templates.GetRowByName("Detail_Package")("Template_body")
        sTemplate = sTemplate.Replace("#name#", oPkg.Name)
        sTemplate = sTemplate.Replace("#notes#", oPkg.Notes)
        sTemplate = sTemplate.Replace("#list_packages#", Me.PubliceerListPackages(oPkg.Packages))
        sTemplate = sTemplate.Replace("#list_diagrams#", Me.PubliceerListDiagrams(oPkg.Diagrams))

        'when we want to create a pdf of the package it is created here including a hyperlink to this pdf file
        If oPkg.Diagrams.Count > 0 And Me.blnCreatePDF = True Then
            MaakDocumentVoorPackage(oPkg)
            sTemplate = sTemplate.Replace("#packagepdf#", "<a target='_blank' href='packagedocument" + oPkg.PackageID.ToString() + ".pdf' >Open PDF document</a>")
        Else
            sTemplate = sTemplate.Replace("#packagepdf#", "")
        End If

        Export2HTML("package" + oPkg.PackageID.ToString(), sTemplate)
    End Sub
    ''' <summary>
    ''' Write the constructed sitemap to a file 
    ''' </summary>
    Sub PublishSiteMap()
        Export2HTML("SiteMap", oSBSiteMap.ToString())
    End Sub
    ''' <summary>
    ''' Convert an element and a diagramobject in a diagram to a map tag in a html construction. In here a number of calculations and transformations are needed
    ''' </summary>
    ''' <param name="oElement">Element to process</param>
    ''' <param name="oDO">Data object to process (read the coordinates)</param>
    ''' <param name="MinX">Min X position of alle the elements</param>
    ''' <param name="MinY">Min Y position of alle the elements</param>
    ''' <param name="MaxX">Max X position of alle the elements when resizing is needed</param>
    ''' <returns></returns>
    Public Function Element2Map(ByVal oElement As EA.Element, ByVal oDO As EA.DiagramObject, ByVal MinX As Double, ByVal MinY As Double, ByVal MaxX As Double) As String
        Dim sCoord
        Dim dFactor As Double
        sCoord = ""

        If Me.blnDiagElemCombined = False And ((oElement.IsComposite = True And Me.blnCompositeClickable = True) Or Me.blnCompositeClickable = False) Then
            'dFactor = Convert.ToDouble(650 / MaxX)
            'Calculate the coordinates for each part of an element
            dFactor = 1
            sCoord += "<area shape='rect' coords='"
            sCoord += Int(Convert.ToDouble(oDO.left - MinX) * dFactor).ToString() + ","
            sCoord += Int(Convert.ToDouble(Math.Abs(oDO.top) - MinY) * dFactor).ToString() + ","
            sCoord += Int(Convert.ToDouble(oDO.right - MinX) * dFactor).ToString() + ","
            sCoord += Int(Convert.ToDouble(Math.Abs(oDO.bottom) - MinY) * dFactor).ToString() + "' target='_self'  "
            If oElement.IsComposite = True Then
                sCoord += " href='diagram" + oElement.CompositeDiagram.diagramID.ToString() + ".html' >"
            Else
                sCoord += " href='element" + oElement.ElementID.ToString() + ".html' >"
            End If
        End If
        Element2Map = sCoord
    End Function
    ''' <summary>
    ''' Publish a diagram and all the elements to a html page
    ''' </summary>
    ''' <param name="oDgm"></param>
    Public Sub PubliceerDiagram(ByVal oDgm As EA.Diagram)
        Dim oSBInhoud As New StringBuilder()
        Dim sFNaam As String
        Dim oElement As EA.Element
        Dim oDiagramObject As EA.DiagramObject
        Dim sOpsommingElement As String
        Dim sMap As String
        Dim iMinX As Integer
        Dim iMinY As Integer
        Dim iMaxX As Integer

        Try
            'If the diagram is already processed in a previous step stop here
            ' If File.Exists(FullFileName(sPath, "diagram" + oDgm.DiagramID.ToString())) Then
            'Me.CheckAndRemoveDiagram(oDgm.DiagramID.ToString())
            'Return
            'End If
            MaakSiteMapURL(MaakURL(oDgm.Name, "diagram" + oDgm.DiagramID.ToString()), False)

            'Aanmaken content obv de variabelen in het object	
            oSBInhoud.Append("<h2>" + oDgm.Name + "</h2>")

            'Aanmaken map elementen	
            sMap = "<map name='teamap' >"

            'Plaatje exporteren en img tag maken	
            oSBInhoud.Append("<img src='diagram" + oDgm.DiagramID.ToString() + ".png' alt='EA image' usemap=#teamap >#map#")

            'when there are notes add it to the HTML
            If Len(oDgm.Notes) > 0 Then
                oSBInhoud.Append("<p>" + oDgm.Notes + "</p>")
            End If

            'calculate the min and max coordinates for all elements in the diagram
            'necessary for positioning the rect elements
            iMaxX = 0
            iMinX = 1000
            iMinY = 1000
            For Each oDiagramObject In oDgm.DiagramObjects
                If Math.Abs(oDiagramObject.top) < iMinY Then
                    iMinY = Math.Abs(oDiagramObject.top)
                End If
                If oDiagramObject.left < iMinX Then
                    iMinX = oDiagramObject.left
                End If
                If oDiagramObject.right > iMaxX Then
                    iMaxX = oDiagramObject.right
                End If
            Next
            'create all the elements based on the option of a combined diagram element page or not
            If DiagElemCombined = True Then
                sOpsommingElement = ""
                For Each oDiagramObject In oDgm.DiagramObjects
                    oElement = Me.Repository.GetElementByID(oDiagramObject.ElementID.ToString())
                    sOpsommingElement += SamenStellenElement(oElement)
                    sMap += Element2Map(oElement, oDiagramObject, iMinX, iMinY, iMaxX)
                Next
            Else
                sOpsommingElement = "<ul>"
                For Each oDiagramObject In oDgm.DiagramObjects
                    oElement = Repository.GetElementByID(oDiagramObject.ElementID.ToString())
                    Dim sText As String
                    sText = SamenStellenElement(oElement)
                    If sText.Length > 0 Then
                        sOpsommingElement += "<li>" + MaakURL(oElement.Name, "element" + oElement.ElementID.ToString()) & "</li>"
                        Export2HTML("element" & oElement.ElementID.ToString(), sText)
                    End If
                    sMap += Element2Map(oElement, oDiagramObject, iMinX, iMinY, iMaxX)
                Next
            End If
            sMap = sMap & "</map>"
            oSBInhoud.Replace("#map#", sMap)

            If Len(sOpsommingElement) > 5 Then
                oSBInhoud.Append("<ul>" + sOpsommingElement + "</ul>")
            End If
            SaveDiagramImage(oDgm.DiagramID)

            'Wegschrijven van het materiaal naar een html bestand	
            sFNaam = "diagram" & oDgm.DiagramID.ToString()
            Export2HTML(sFNaam, oSBInhoud.ToString())
        Catch ex As Exception
            Repository.WriteOutput("IDEA", ex.ToString(), 0)
        End Try

    End Sub
    ''' <summary>
    ''' Create the content of an element and return it as a string
    ''' </summary>
    ''' <param name="oEle"></param>
    ''' <returns>HTML string of the processed element content</returns>
    Public Function SamenStellenElement(ByVal oEle As EA.Element) As String

        Dim oSBInhoud As New StringBuilder("")
        Dim blnHasData As Boolean = False

        'Aanmaken content obv de variabelen in het object	
        oSBInhoud.Append("<h2>" & oEle.Name & "</h2>")

        If Len(oEle.Notes) > 0 Then
            oSBInhoud.Append("<p>" & oEle.Notes & "</p>")
            blnHasData = True
        End If

        Dim sAttributes As String
        sAttributes = "<table><tr><th>Name</th><th>Type</th><th>Description</th></tr>"
        Dim oAttribute As EA.Attribute
        For Each oAttribute In oEle.Attributes
            sAttributes += "<tr><td>" + oAttribute.Name + "</td><td>" + oAttribute.Type + "</td><td>" + oAttribute.Notes + "</td></tr>"
        Next
        If sAttributes.Contains("<td>") Then
            sAttributes = sAttributes + "</table><br>"
            oSBInhoud.Append("<strong>Attributes</strong>" + sAttributes)
            blnHasData = True
        End If

        Dim sMethods As String
        sMethods = "<table><tr><th>Name</th><th>Description</th></tr>"
        Dim oMethod As EA.Method
        For Each oMethod In oEle.Methods
            sMethods += "<tr><td>" + oMethod.Name + "</td><td>" + oMethod.Notes + "</td></tr>"
        Next
        If sMethods.Contains("<td>") Then
            sMethods = sMethods + "</table><br>"
            oSBInhoud.Append("<strong>Methods</strong>" + sMethods)
            blnHasData = True
        End If

        Dim sConstraints As String
        Dim oConstraint As EA.Constraint
        sConstraints = "<table><tr><th>Name</th><th>Type</th><th>Description</th></tr>"
        For Each oConstraint In oEle.Constraints
            sConstraints += "<tr><td>" + oConstraint.Name + "</td><td>" + oConstraint.Type + "</td><td>" + oConstraint.Notes + "</td></tr>"
        Next
        If Len(sConstraints) > 85 Then
            sConstraints = sConstraints + "</table><br>"
            oSBInhoud.Append("<strong>Constraints</strong>" + sConstraints)
            blnHasData = True
        End If

        Dim sFile
        Dim oFile As EA.File
        sFile = "<ul>"
        For Each oFile In oEle.Files
            sFile = sFile & "<li><a href='" + oFile.Name & "' >" + oFile.Name + "</a> &nbsp;" + oFile.Notes + "</li>"
        Next
        If Len(sFile) > 5 Then
            sFile += "</ul>"
            oSBInhoud.Append("<strong>Linked files</strong>" + sFile)
            blnHasData = True
        End If
        'If the element Is a composite we need to add the diagram to the list of to be processed diagrams
        If oEle.IsComposite Then
            Me.oSBSideBar.Append("<li>" + MaakURL(oEle.CompositeDiagram.Name, "diagram" + oEle.CompositeDiagram.diagramID.ToString()) + "</li>")
            Me.CheckAndAddDiagram(oEle.CompositeDiagram.diagramID.ToString())
        End If
        'this can be extended with other child elements
        If blnHasData = False Then
            oSBInhoud.Clear()
        End If
        Return oSBInhoud.ToString()

    End Function
    ''' <summary>
    ''' Create a document for the package content
    ''' </summary>
    ''' <param name="oPkg">Package object</param>
    Public Sub MaakDocumentVoorPackage(ByVal oPkg As EA.Package)
        'Aanmaken van een PPF document op basis van reporting object in EA	
        Dim docGenerator As EA.DocumentGenerator
        docGenerator = Repository.CreateDocumentGenerator()

        ' Create a new document
        Try
            If docGenerator.NewDocument("") = True Then
                Dim generationSuccess As Boolean
                generationSuccess = docGenerator.InsertCoverPageDocument(My.Settings.PDFCoverPage)
                docGenerator.InsertBreak(EA.DocumentBreak.breakPage)
                generationSuccess = docGenerator.DocumentPackage(oPkg.PackageID, 3, My.Settings.PDFReportTemplate)
                docGenerator.InsertBreak(EA.DocumentBreak.breakPage)
                'process the diagram and all its containing elements independent of the package structure
                Dim oDiagram As EA.Diagram

                For Each oDiagram In oPkg.Diagrams
                    generationSuccess = docGenerator.DocumentDiagram(oDiagram.DiagramID, 0, My.Settings.PDFReportTemplate)
                    Dim oElement As EA.DiagramObject
                    For Each oElement In oDiagram.DiagramObjects
                        generationSuccess = docGenerator.DocumentElement(oElement.ElementID, 0, My.Settings.PDFReportTemplate)
                    Next
                    docGenerator.InsertBreak(EA.DocumentBreak.breakPage)
                Next
                ' Save the document
                Dim saveSuccess As Boolean
                saveSuccess = docGenerator.SaveDocument(sPath & "packagedocument" & oPkg.PackageID.ToString() & ".PDF", 2)
            End If
        Catch ex As Exception
            Repository.WriteOutput("IDEA", ex.Message, 0)
        End Try
    End Sub
    ''' <summary>
    ''' delete all the files available in the publication folder
    ''' </summary>
    Sub DeleteFilesInFolder()
        If Directory.Exists(sPath) Then
            For Each _file As String In Directory.GetFiles(sPath)
                File.Delete(_file)
            Next
        End If
    End Sub
    ''' <summary>
    ''' Process the list of diagrams that are hit by the composite diagram items in the processed diagrams
    ''' ''' </summary>
    Sub PubliceerALdiagrams()
        Dim intAantal As Integer
        intAantal = -99
        'weird routine but this is necessary since new diagrams can be added in this loop
        While Me.oALDiagrams.Count > 0
            Dim ID As String
            ID = oALDiagrams.Item(0)
            PubliceerDiagram(Repository.GetDiagramByID(ID))
            Me.CheckAndRemoveDiagram(ID)
        End While


    End Sub
    ''' <summary>
    ''' Generate the documentation based on the first package
    ''' </summary>
    ''' <param name="oPackage">The rootpackage to start processing</param>
    Public Sub Generate(ByVal oPackage As EA.Package)
        Try
            Repository.CreateOutputTab("IDEA")
            DeleteFilesInFolder()
            Repository.WriteOutput("IDEA", "Generator is started", 0)
            PubliceerRootPackage(oPackage)
            PubliceerALdiagrams()
            PublishSiteMap()
            Repository.WriteOutput("IDEA", "Generator is ready", 0)
        Catch ex As Exception
            Repository.WriteOutput("IDEA", ex.Message, 0)
        End Try
    End Sub
End Class
